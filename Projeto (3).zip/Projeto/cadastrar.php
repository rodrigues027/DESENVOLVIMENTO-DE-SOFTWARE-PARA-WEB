<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>cadastro</title>
 </head>
 <body>
 <?php
 include_once "Medicamento.php";
 include_once "MedicamentoDao.php";
 $id = intval($_POST["id"]);
 $nome = $_POST["nome"];
 $indicado = $_POST["indicado"];
 $preço = floatval($_POST["preço"]);
 $f = new medicamentos($id,$nome,$indicado,$preço);
 $dao = new MedicamentoDao();
 if ( $dao->inserir($f) ) {
	 echo "<p>".$f->getNome()." inserido</p>";
}
?>

</body>
</html>