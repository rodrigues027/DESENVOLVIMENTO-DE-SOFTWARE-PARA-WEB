<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Resultado</title>
</head>
<body>
<?php
include_once "MedicamentoDao.php";
include_once "Medicamento.php";
$id=intval($_GET["id"]);
$dao = new MedicamentoDao();
$f = new Medicamentos($id,null,null,null );

echo "<p>";
if( $dao->excluir($f) ) {
  echo "excluído";
} else {
  echo "não encontrado";
}
echo "</p>";
?>
<a href="/aula">voltar</a>
</body>
</html>