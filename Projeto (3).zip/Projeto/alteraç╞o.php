<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>Alteração</title>
</head>
<body>
<?php
include_once "MedicamentoDao.php";
include_once "Medicamento.php";
$id = intval($_POST["id"]);
$nome = $_POST["nome"];
$indicado = $_POST["indicado"];
$preço = floatval($_POST["preço"]);
$f = new Medicamentos($id,$nome,$indicado,$preço);
$dao = new MedicamentoDao();
if( $dao->alterar($f) ) {
  echo "<p>".$f->getNome()." alterado</p>";
}
?> 
<a href='/aula'>voltar</a> 
 </body>
 </html>