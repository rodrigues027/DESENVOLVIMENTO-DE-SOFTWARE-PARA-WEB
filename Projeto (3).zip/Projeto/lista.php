<!DOCTYPE html>
<html>
<head>
  <meta charset="ISO-8859-1">
  <title>Listagem dos Medicamentos</title>
</head>
<body>
<table border='1'>
<tr>
  <th>id</th>
  <th>nome</th>
  <th>indicado</th>
  <th>preço</th>
</tr>
<?php
include_once "MedicamentoDao.php";
include_once "MedicamentoDao.php";

$dao = new MedicamentoDao();	
$lista = $dao->listar();
$formatter = new NumberFormatter('pt_BR',NumberFormatter::CURRENCY);
foreach($lista as $f) {
  echo "<tr><td>".$f->getId()."</td>";
  echo "<td>".$f->getNome()."</td>";
  echo "<td>".$f->getIndicado()."</td>";
  echo "<td>".$formatter->formatCurrency($f->getPreço(),"BRL")."</td></tr>";
}
?>
</table>
<a href="/aula">voltar</a>
</body>
</html>