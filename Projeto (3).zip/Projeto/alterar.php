<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
<title>Alteração</title>
</head>
<body>
<?php
include_once "Medicamento.php";
include_once "MedicamentoDao.php";
$id = intval($_POST["id"]);
$dao = new MedicamentoDao();
$f = $dao->buscarPeloId($id);
$indicado = $f->getIndicado();
?>

<form action='alteração.php' method='post'>
id:<input type="text" name="id" value="<?php echo $f->getId();?>" /><br/>
nome:<input type="text" name="nome" value="<?php echo $f->getNome();?>"/><br/>
indicado:<input type="text" name="indicado" value="<?php echo $f->getIndicado();?>"/><br/>
preço:<input type="text" name="preço" value="<?php echo $f->getPreço();?>"/><br/>
<input type="submit" value="enviar"/>
</form>
<a href='/aula'>voltar</a>
</body>

</html>