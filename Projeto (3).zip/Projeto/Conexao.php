<?php
$conn=new mysqli("localhost","root","123456","Trabalho");
?>
