create table medicamentos(
  id int,
  nome varchar(50),
  indicado varchar(50),
  preço int, 
  primary key(id));

insert into medicamentos values( 1, 'Paracetamol', 'Dor e Febre', 10 );
insert into medicamentos values( 2, 'Azitromicina', 'Infecções respiratórias', 23 );
insert into medicamentos values( 3, 'Buscopan', 'Dor abdominal', 20 );
insert into medicamentos values( 4, 'Eno', 'Azia', 5 );
insert into medicamentos values( 5, 'Nimesulida', 'Inflamação', 10 );

update medicamentos
set nome = 'Eno',
    indicado = 'Azia',
	preço = 3
where id = 4;

delete from medicamentos where id = 5;


SELECT * FROM medicamentos;

SELECT * FROM medicamentos WHERE id = 2;



