<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
<title>Formulário</title>
</head>
<body>
<form action='cadastrar.php' method='post'>
ID:<input type="text" name="id"/><br/>
nome:<input type="text" name="nome"/><br/>
indicado:<input type="text" name="indicado"/><br/>
preço:<input type="text" name="preço"/><br/>
<input type="submit" value="enviar"/>
</form>
<a href='/aula'>voltar</a>
</body>

</html>