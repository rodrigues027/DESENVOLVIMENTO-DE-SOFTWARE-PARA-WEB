<?php
class medicamentos {
	private $id;
	private $nome;
	private $indicado;
	private $preço;
	
	function __construct($id,$nome,$indicado,$preço){
		$this->id = $id;
		$this->nome=$nome;
		$this->indicado = $indicado;
		$this->preço = $preço;
	}
	public function getId() {
		return $this->id;
	}
	public function setId($id) {
		$this->id = $id;
	}
	public function getNome() {
		return $this->nome;
	}
	public function setNome($nome) {
		$this->nome = $nome;
		
	}public function getIndicado() {
		return $this->indicado;
	}
	public function setIndicado($indicado) {
		$this->indicado = $indicado;
		
	}public function getPreço() {
		return $this->preço;
	}
	public function setPreço($preço) {
		$this->preço = $preço;
	}
}	

?>