<?php
include_once("Medicamento.php");
include_once("Conexao.php");

class MedicamentoDao {

	public function inserir(Medicamentos $medicamentos) {
		global $conn;
		$sql=$conn->prepare("INSERT INTO MEDICAMENTOS VALUES(?,?,?,?)");
		$p1 = $medicamentos->getId();
		$p2 = $medicamentos->getNome();
		$p3 = $medicamentos->getIndicado();
		$p4 = $medicamentos->getPreço();
		$sql->bind_param("issd",$p1,$p2,$p3,$p4);
		$sql->execute();
		if($sql->affected_rows>0) {
			return true;
		}
	}

	public function excluir(Medicamentos $medicamentos) {
		global $conn;
		$sql=$conn->prepare("DELETE FROM MEDICAMENTOS WHERE ID=?");
		$p1 = $medicamentos->getId();
		$sql->bind_param("i",$p1);
		$sql->execute();
		if($sql->affected_rows>0) {
			return true;
		}
	}
	
	public function alterar(Medicamentos $medicamentos) {
	global $conn;
	$sql=$conn->prepare(
	"UPDATE MEDICAMENTOS SET NOME=?,INDICADO=?,PREÇO=? WHERE ID=?");
	$p1 = $medicamentos->getNome();
	$p2 = $medicamentos->getIndicado();
	$p3 = $medicamentos->getPreço();
	$p4 = $medicamentos->getId();
	$sql->bind_param("ssdi",$p1,$p2,$p3,$p4);
	$sql->execute();
	if($sql->affected_rows>0) {
		return true;
	}
  }
  
  public function listar() {
	  global $conn;
	  $sql = "SELECT id,nome,indicado,preço FROM Medicamentos";
	  $result=mysqli_query($conn,$sql);
	  $lista=array();
	  while( $row = $result->fetch_assoc()) {
		array_push($lista, new Medicamentos($row["id"],$row["nome"],
		  $row["indicado"],$row["preço"]));
	  }
	  return $lista;
  }
  
      public function buscarPeloId($id) {
        global $conn;
        $nome="";
        $indicado="";
        $preço=0.0;
        $sql = "SELECT * FROM Medicamentos WHERE id=?";
        $query = $conn->prepare($sql);
        $result=$query->bind_param("i",$id);
        $query->execute();
        $query->bind_result($id,$nome,$indicado,$preço);
        if( $query->fetch()) {
            return new Medicamentos($id,$nome,$indicado,$preço);
        }
    }

  
  
  
  
}

?>